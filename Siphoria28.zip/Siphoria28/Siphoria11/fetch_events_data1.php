<?php
require 'connect_to_db.php';




$sql = "SELECT team_name, scores, location_id,event_id,event_name
FROM participation WHERE location_id ='1111' order by event_id";

$result = mysqli_query($conn, $sql);

$i =1;
$j = 1;
$k=1;
$l=1;

$event1 = "";


if (mysqli_num_rows($result) > 0) {

while($row1 = mysqli_fetch_assoc($result)) {

  if($i==1)
  {
    $event = $row1['event_name'];
    echo " <table class='table table-bordered deloitteFontColor'><tr><th  colspan = '5'><center>Mumbai</cemter></th></tr><tr>
        <th  align = 'center'>Events</th>
        <th>Targarean</th>
          <th>Stark</th>
            <th>Lannister</th>
              <th>Baratheon</th>
      </tr><tr>";



  }
  if($i%4!=0)
  {

     if($i%4==1)
     {
       $event = $row1['event_name'];
       echo "<td>$event</td>";
    }
    $score = $row1['scores'];
        echo "<td>$score</td>";

  }
  else{

      $score = $row1['scores'];
          echo "<td>$score</td></tr><tr>";

    }





  $i++;

      }

  echo "</table><br><br><br>";




}


else {
    echo "0 results";
}







mysqli_close($conn);
?>
