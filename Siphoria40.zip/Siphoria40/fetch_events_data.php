<?php
require 'connect_to_db.php';
$sql = "SELECT team_name, scores, location_id,event_id,event_name
FROM participation WHERE location_id ='1111';

";
$result = mysqli_query($conn, $sql);

$i =1;
$event1 = "";
if (mysqli_num_rows($result) > 0) {

while($row1 = mysqli_fetch_assoc($result)) {
$event1 = $row1['event_name'];

}



while($row = mysqli_fetch_assoc($result)) {

if($i==1)
{
  $event = $row['event_name'];
  echo " <table><tr >
      <th>Events</th>
      <th>Targarean</th>
        <th>Stark</th>
          <th>Lannister</th>
            <th>Baratheon</th>
    </tr><tr><td>".$event."</td>";



}


if($i%4!=0)
{

  // if($i%4==1)
  // {
  //   $event = $row['event_name'];
  //   echo "<td>$event</td>";
  // }
  $score = $row['scores'];
      echo "<td>$score</td>";

}
else{

    $score = $row['scores'];
        echo "<td>$score</td></tr><tr><td></td>";

  }





$i++;

    }

echo "</table><br><br><br>";
}

else {
    echo "0 results";
}


// $sql1 = "SELECT team_name, scores, location_id,event_id,event_name
// FROM participation WHERE location_id ='1112';
//
// ";
// $result1 = mysqli_query($conn, $sql1);
//
// $i1 =1;
//
// if (mysqli_num_rows($result1) > 0) {
//
//
// while($row1 = mysqli_fetch_assoc($result1)) {
//
// if($i1==1)
// {
//   $event1 = $row1['event_name'];
//   echo " <table><tr >
//       <th>Events</th>
//       <th>Targarean</th>
//         <th>Stark</th>
//           <th>Lannister</th>
//             <th>Baratheon</th>
//     </tr><tr>";
//
//
//
// }
//
// if($i1%4!=0)
// {
//
//   if($i1%4==1)
//   {
//     $event1 = $row1['event_name'];
//     echo "<td>$event1</td>";
//   }
//   $score1 = $row1['scores'];
//       echo "<td>$score1</td>";
//
// }
// else{
//
//     $score1 = $row1['scores'];
//         echo "<td>$score1</td></tr><tr>";
//
//   }
//
//
//
//
//
// $i1++;
//
//     }
//
// echo "</table><br><br><br>";
// }
//
// else {
//     echo "0 results";
// }
//
//
//
//
//
//
// $sql2 = "SELECT team_name, scores, location_id,event_id,event_name
// FROM participation WHERE location_id ='1113';
//
// ";
// $result2= mysqli_query($conn, $sql2);
//
// $i2 =1;
//
// if (mysqli_num_rows($result2) > 0) {
//
//
// while($row2 = mysqli_fetch_assoc($result2)) {
//
// if($i2==1)
// {
//   $event2 = $row2['event_name'];
//   echo " <table><tr >
//       <th>Events</th>
//       <th>Targarean</th>
//         <th>Stark</th>
//           <th>Lannister</th>
//             <th>Baratheon</th>
//     </tr><tr>";
//
//
//
// }
//
// if($i2%4!=0)
// {
//
//   if($i2%4==1)
//   {
//     $event2 = $row2['event_name'];
//     echo "<td>$event2</td>";
//   }
//   $score2 = $row2['scores'];
//       echo "<td>$score2</td>";
//
// }
// else{
//
//     $score2 = $row2['scores'];
//         echo "<td>$score2</td></tr><tr>";
//
//   }
//
//
//
//
//
// $i2++;
//
//     }
//
// echo "</table><br><br><br>";
// }
//
// else {
//     echo "0 results";
// }
//
//
// $sql3 = "SELECT team_name, scores, location_id,event_id,event_name
// FROM participation WHERE location_id ='1114';
//
// ";
// $result3= mysqli_query($conn, $sql3);
//
// $i3 =1;
//
// if (mysqli_num_rows($result3) > 0) {
//
//
// while($row3 = mysqli_fetch_assoc($result3)) {
//
// if($i3==1)
// {
//   $event3 = $row3['event_name'];
//   echo " <table><tr >
//       <th>Events</th>
//       <th>Targarean</th>
//         <th>Stark</th>
//           <th>Lannister</th>
//             <th>Baratheon</th>
//     </tr><tr>";
//
//
//
// }
//
// if($i3%4!=0)
// {
//
//   if($i3%4==1)
//   {
//     $event3 = $row3['event_name'];
//     echo "<td>$event3</td>";
//   }
//   $score3 = $row3['scores'];
//       echo "<td>$score3</td>";
//
// }
// else{
//
//     $score3 = $row3['scores'];
//         echo "<td>$score3</td></tr><tr>";
//
//   }
//
//
//
//
//
// $i3++;
//
//     }
//
// echo "</table><br><br><br>";
// }
//
// else {
//     echo "0 results";
// }























mysqli_close($conn);
?>
