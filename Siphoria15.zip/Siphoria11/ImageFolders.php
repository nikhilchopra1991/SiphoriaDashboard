<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "si_events";
// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

$query = "SELECT distinct gallery_year FROM Gallery";

$result = mysqli_query($conn, $query);


$i = 0;

while ($rows = mysqli_fetch_array($result))
{

           if($i % 3 == 0)
{         echo "<tr>";
}
	$name = $rows['gallery_year'];
          echo"<td><a/>".$name."</td>";
if($i % 3 == 2)
{
  echo"</tr>";
}
$i++;
     }





?>
