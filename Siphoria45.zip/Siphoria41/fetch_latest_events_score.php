<?php
require 'connect_to_db.php';
$sql = "SELECT scores
FROM participation
WHERE event_id = (
SELECT max( event_id )
FROM EVENTS)
";
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0) {

while($row = mysqli_fetch_assoc($result)) {

    echo $row["scores"].">";



    }


}

else {
    echo "0 results";
}

mysqli_close($conn);
?>
