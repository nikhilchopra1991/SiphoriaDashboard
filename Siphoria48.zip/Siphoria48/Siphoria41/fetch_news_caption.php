<?php
require 'connect_to_db.php';
$sql = "SELECT news_id, caption
FROM news_feed
ORDER BY timestamp_news DESC
LIMIT 4
";
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0) {

while($row = mysqli_fetch_assoc($result)) {
$news_id = $row['news_id'];
$title = $row['caption'];

    echo $title .">";



    }


}

else {
    echo "0 results";
}

mysqli_close($conn);
?>
