<?php

require 'connect_to_db.php';


$q= $_REQUEST["q"];


$sql = "SELECT name, logo_path,captain,description,projects
FROM team
WHERE  name = '".$q."'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

$row = mysqli_fetch_assoc($result);
$logo = $row['logo_path'];
$name = $row['name'];
$captain = $row['captain'];
$description = $row['description'];
$project = $row['projects'];
  echo "<style>
			/* centered columns styles */
			.row-centered {
				text-align:center;
			}
			.col-centered {
				display:inline-block;
				float:none;
				/* reset the text-align */
				text-align:left;
				/* inline-block space fix */
				margin-right:-4px;
			}
		</style>
		<div class='modal-popup' style='display:block;'>
		<div class = 'modal-header'>


                        <button type='button' class='close' data-dismiss='modal'>&times;</button>
                           <img id = 'Targarean_Image'src='".$logo."' width='70' height='100' alt='House Targaryen' class='inlineHeader col-sm-6 col-md-4 col-lg-2'>
                           <h3 class='modal-title inlineHeader col-sm-6 col-md-8 col-lg-8'>".$name."</h3>
               </div>
                              <div class='modal-body' id = 'modal_body_targarean'>
                                 <p><h5>".$description.".</h5></p><br /><br/>
								 <hr/>
                                 <h4 class='inlineHeader' style='text-align:center; margin-left:50px;'>Captain</h4>
								 <div class='captains' style='width:90%; margin-left:30%; margin-right:30%;' class='row row-centered'>
									 <div ='captain' class='col-lg-3'>
										<img id = 'Targarean_Image'src='".$logo."' height='100' width='100' alt='House Targaryen' class='img-circle'>
										<h5 class='inlineHeader' style='text-align:center;'>".$captain."</h5>
									</div>
									<div ='captain' class='col-lg-3'>
										<img id = 'Targarean_Image'src='".$logo."' height='100' width='100' alt='House Targaryen' class='img-circle'>
										<h5 class='inlineHeader' style='text-align:center;'>".$captain."</h5>
									 </div>
								 </div>
								 <div class='clearfix visible-lg-block'></div>
								 <div class='spocs' style='width:100%;'>
									<div class='spocCol col-lg-6'>
										<div class='spocRow'>
											<h6 style='text-align:center;'>Mumbai</h6>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:30px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='spocName' style='margin-left:50px; text-align:center;'>".$captain."</h5>
											</div>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:50px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='spocName' style='margin-left:70px; text-align:center;'>".$captain."</h5>
											</div>
										</div>
									</div>
									<div class='spocCol col-lg-6'>
										<div class='spocRow'>
											<h6 style='text-align:center;'>Hyderabad</h6>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:30px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='spocName' style='margin-left:50px; text-align:center;'>".$captain."</h5>
											</div>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:50px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='spocName' style='margin-left:70px; text-align:center;'>".$captain."</h5>
											</div>
										</div>
									</div>
									<div class='spocCol col-lg-6'>
										<div class='spocRow'>
											<h6 style='text-align:center;'>Banglore</h6>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:30px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='inlineHeader' style='margin-left:50px; text-align:center;'>".$captain."</h5>
											</div>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:50px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='inlineHeader' style='margin-left:70px; text-align:center;'>".$captain."</h5>
											</div>
										</div>
									</div>
									<div class='spocCol col-lg-6'>
										<div class='spocRow'>
											<h6 style='text-align:center;'>Gurgaon</h6>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:30px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='inlineHeader' style='margin-left:50px; text-align:center;'>".$captain."</h5>
											</div>
											<div class='spoc col-lg-3'>
												<img id ='Targarean_Image' style='margin-left:50px;' src='".$logo."' height='80' width='80' alt='House Targaryen' class='img-circle'>
												<h5 class='inlineHeader' style='margin-left:70px; text-align:center;'>".$captain."</h5>
											</div>
										</div>
									</div>
								</div>
								<div class='clearfix visible-lg-block'></div>
								 <br /><br/>
								 <hr/>
                                 <h4 class='inlineHeader' style='text-align:center; margin-left:50px;'>Projects Involved</h4>
								 <div class='downloadButton' style='margin-left:40%;'>
									<button type='button' class='btn btn-default'style='width:150px;height:50px;'>Download</button>
								 </div>
                             </div>
                             <div class='modal-footer'>
               <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                             </div>
							 </div>
                    ";




}








?>
